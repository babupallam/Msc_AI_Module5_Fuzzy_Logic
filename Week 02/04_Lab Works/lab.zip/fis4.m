%% LAB 4
variables:
1. linguistic salary (Isalary) -- (0 to 100000)
        low- shoulders
        medium - trapz
        high - shoulders
2. linguistic pediod of employment (Iperiod) --- 
        very low, -- tri 
        low, 
        medium, 
        high, 
        very high
3. decision --- 
        low, 
        medium, 
        high