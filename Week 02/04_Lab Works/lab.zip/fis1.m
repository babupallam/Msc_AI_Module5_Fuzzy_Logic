% This m-file creates a linguistic variable for age with three linguistic
% labels - young, middleaged and old. The first statement creates a new FIS
% with string name test and Matlab variable a. The FIS adopts certain defaults.
a = mamfis('Name',"test");

% This adds a variable called ’linguistic age’ to the FIS which is
% of type input and lies between 0 and 70.
a = addInput(a,[0 70],'Name',"linguistic age");
% We now add three membership functions associated with this variable.
a = addMF(a,"linguistic age","gaussmf",[10 0],'Name',"young");
a = addMF(a,"linguistic age","gaussmf",[10 40],'Name',"middleaged");
a = addMF(a,"linguistic age","gaussmf",[10 70],'Name',"old");


% This plots the membership functions:
plotmf(a,'input',1)