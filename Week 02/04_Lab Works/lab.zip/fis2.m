% This m-file creates a linguistic variable for age with three linguistic
% labels - young, middleaged and old. The first statement creates a new FIS
% with string name test and Matlab variable a. The FIS adopts certain defaults.


a = mamfis('Name',"test");

% This adds a variable called ’linguistic age’ to the FIS which is
% of type input and lies between 0 and 70.
a = addInput(a,[0 70],'Name',"linguistic age");
% We now add three membership functions associated with this variable.
a = addMF(a,"linguistic age","gaussmf",[10 0],'Name',"young");
a = addMF(a,"linguistic age","gaussmf",[10 40],'Name',"middleaged");
a = addMF(a,"linguistic age","gaussmf",[10 70],'Name',"old");

%%
% Now add a new variable into your m-file called ‘male linguistic weight’ which describes someone
% as small, medium or large over a domain ranging from 65Kg to 120Kg. Use triangular membership
% functions. Plot the result.

%add variable named "linquistic male" to the FIS which is of type input
%lies in between 65 and 120kg
a= addInput(a,[65,120],'Name',"linguistic weight");
% add three membership functions over the domain
a = addMF(a,"linguistic weight","trimf",[65,70 80],'Name',"small");
a = addMF(a,"linguistic weight","trimf",[70,85 100],'Name',"medium");
a = addMF(a,"linguistic weight","trimf",[80,100 120],'Name',"large");

% This plots the membership functions:
% plotmf(a,'input',1)
% plotmf(a,'input',2)


%% 
% Finally add a third variable to the same m-file ’male linguistic foot size’ choosing five sensible labels
% and domain. Use membership functions that are not gaussian or triangular

%add variable named "linquistic foot size" to the FIS which is of type input
%lies in between UK3 to UK12
a= addInput(a,[3,12],'Name',"linguistic foot size");
% add three membership functions over the domain
a = addMF(a,"linguistic foot size","trapmf",[2,3,4,5],'Name',"uk3");
a = addMF(a,"linguistic foot size","trapmf",[3,5,6,7],'Name',"uk5");
a = addMF(a,"linguistic foot size","trapmf",[4,7,8,9],'Name',"uk7");
a = addMF(a,"linguistic foot size","trapmf",[7,9,10,11],'Name',"uk9");
a = addMF(a,"linguistic foot size","trapmf",[9,10,11,12],'Name',"uk11");

% This plots the membership functions:
plotmf(a,'input',1)
figure
plotmf(a,'input',2)
figure
plotmf(a,'input',3)

